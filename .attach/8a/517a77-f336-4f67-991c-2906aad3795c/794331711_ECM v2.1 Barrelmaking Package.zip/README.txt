Description:
	This is the updated DIY 9x19mm ECM barrelmaking tutorial. Significantly refined from the previous version, this setup and process should now be able to establish a standard for future ECM projects. Later updates to this project will include options for different barrel lengths, calibers, etc.
	One note to address early - the rifling mandrel/setup included in the first release of this updated process is a progressive rifled mandrel - this provides interesting benefits to the barrel you make, but you should be aware that your barrel length must be 4.5" (114.3mm) due to the way progressive rifling works (it can be between 4.3" (109.2mm) and 4.7" (119.4mm), but cannot be much shorter or longer).

Note: 
	This document contains general information and print info. Refer to the "Documentation" folder for in-depth instructions.

Print settings:
	**All STL files are scaled and oriented correctly.** There is no need to change the orientation or scale of any parts, and doing so may cause issues.

	Only two of the parts should be printed with supports - these are the chambering end pilot and throating end pilot. Print these parts using "Supports from print bed only".
	All other parts should be printed without supports.

***Print settings for all parts***
	Material: eSun PLA+
	Infill: 100%
	Temps: 230C Nozzle/60C Bed
	Cooling Fan: Set to off (turn off 'fan always on' setting), enable autocooling (if such an option exists) with speed set between 35% min, 60% max, can be 80% for bridges (your exact settings will depend on your printer and slicer, but low cooling is desired)
	Nozzle: MUST BE 0.4MM
	Layer Height: Strongly Recommend 0.15mm or 0.16mm on all parts except the rifling mandrel - on the rifling mandrel, use 0.12mm layer height - this will make the wires a little eaiser to install in the mandrel.
	Bed Adhesion: gluestick or hairspray or both

	All other settings can/should be left as default or whatever you know works best with your printing setup.

The folder "Alternate Parts" will contain alternate solutions that you can print, such as the hose fittings.