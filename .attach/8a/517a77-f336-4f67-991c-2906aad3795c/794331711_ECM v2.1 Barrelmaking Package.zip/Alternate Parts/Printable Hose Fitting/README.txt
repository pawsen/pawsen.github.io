Print this hose fitting in the scale and orientation of the provided STL file.

Print with supports from print bed only.

Material: eSun PLA+
Infill: 100%
Temps: 230C Nozzle/60C Bed
Cooling Fan: Set to off (turn off 'fan always on' setting), enable autocooling (if such an option exists) with speed set between 35% min, 60% max, can be 80% for bridges (your exact settings will depend on your printer and slicer, but low cooling is desired)
Nozzle: MUST BE 0.4MM
Layer Height: Strongly Recommend 0.15mm or 0.16mm. If your wires won't fit easily in the wire-based mandrel, try printing it with 0.12 or 0.08mm layer height.
Bed Adhesion: gluestick or hairspray or both

All other settings can/should be left as default or whatever you know works best with your printing setup.